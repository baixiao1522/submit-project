function loadLangHTML(code) {
	var xmlURL = "xml/" + code + ".xml";
	$.get(xmlURL, function(data) {
		$("label[xx='lang']").each(function(d) {
			var value = $(data).find("#" + $(this).attr("class")).text();
			if (value != "") {
				$(this).html(value);
			}
		});
	});
}

$(function() {
	$("body").append("<div style='bottom:10pt; right: 10pt; border:1px solid #ccc; z-index: 5000; position: fixed;'><select id='langGJ'><option value='en'>EngLish</option><option value='zh'>中文</option></select></div>");
	var code;
	if (navigator.language) {
		code = navigator.language;
	} else {
		code = navigator.browserLanguage;
	}
	var index = code.indexOf("-");
	if (index != -1) {
		code = code.substring(0, index);
	}
	loadLangHTML(code);
	$("#langGJ option[value='" + code + "']").attr("selected", true);
	$("#langGJ").live("change", function() {
		var code = $(this).val();
		loadLangHTML(code);
	});
});